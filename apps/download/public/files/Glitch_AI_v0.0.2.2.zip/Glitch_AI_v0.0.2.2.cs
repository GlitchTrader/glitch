#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GlitchAiMarketIngest[] cacheGlitchAiMarketIngest;
		private GlitchAnalyticsBridge[] cacheGlitchAnalyticsBridge;

		
		public GlitchAiMarketIngest GlitchAiMarketIngest(bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			return GlitchAiMarketIngest(Input, addPrimaryTimeframes, additionalInstrumentRoots);
		}

		public GlitchAnalyticsBridge GlitchAnalyticsBridge(double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			return GlitchAnalyticsBridge(Input, neutralBand, enableBarColoring, publishToGlitchUi, publishIntervalMs, intraBarColoring, predictiveBoost, flipHysteresis, performanceMode, enableOrderFlowLayer, orderFlowBlend, enableHistoricalSnapshotExport, historicalExportDirectory);
		}


		
		public GlitchAiMarketIngest GlitchAiMarketIngest(ISeries<double> input, bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			if (cacheGlitchAiMarketIngest != null)
				for (int idx = 0; idx < cacheGlitchAiMarketIngest.Length; idx++)
					if (cacheGlitchAiMarketIngest[idx].AddPrimaryTimeframes == addPrimaryTimeframes && cacheGlitchAiMarketIngest[idx].AdditionalInstrumentRoots == additionalInstrumentRoots && cacheGlitchAiMarketIngest[idx].EqualsInput(input))
						return cacheGlitchAiMarketIngest[idx];
			return CacheIndicator<GlitchAiMarketIngest>(new GlitchAiMarketIngest(){ AddPrimaryTimeframes = addPrimaryTimeframes, AdditionalInstrumentRoots = additionalInstrumentRoots }, input, ref cacheGlitchAiMarketIngest);
		}

		public GlitchAnalyticsBridge GlitchAnalyticsBridge(ISeries<double> input, double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			if (cacheGlitchAnalyticsBridge != null)
				for (int idx = 0; idx < cacheGlitchAnalyticsBridge.Length; idx++)
					if (cacheGlitchAnalyticsBridge[idx].NeutralBand == neutralBand && cacheGlitchAnalyticsBridge[idx].EnableBarColoring == enableBarColoring && cacheGlitchAnalyticsBridge[idx].PublishToGlitchUi == publishToGlitchUi && cacheGlitchAnalyticsBridge[idx].PublishIntervalMs == publishIntervalMs && cacheGlitchAnalyticsBridge[idx].IntraBarColoring == intraBarColoring && cacheGlitchAnalyticsBridge[idx].PredictiveBoost == predictiveBoost && cacheGlitchAnalyticsBridge[idx].FlipHysteresis == flipHysteresis && cacheGlitchAnalyticsBridge[idx].PerformanceMode == performanceMode && cacheGlitchAnalyticsBridge[idx].EnableOrderFlowLayer == enableOrderFlowLayer && cacheGlitchAnalyticsBridge[idx].OrderFlowBlend == orderFlowBlend && cacheGlitchAnalyticsBridge[idx].EnableHistoricalSnapshotExport == enableHistoricalSnapshotExport && cacheGlitchAnalyticsBridge[idx].HistoricalExportDirectory == historicalExportDirectory && cacheGlitchAnalyticsBridge[idx].EqualsInput(input))
						return cacheGlitchAnalyticsBridge[idx];
			return CacheIndicator<GlitchAnalyticsBridge>(new GlitchAnalyticsBridge(){ NeutralBand = neutralBand, EnableBarColoring = enableBarColoring, PublishToGlitchUi = publishToGlitchUi, PublishIntervalMs = publishIntervalMs, IntraBarColoring = intraBarColoring, PredictiveBoost = predictiveBoost, FlipHysteresis = flipHysteresis, PerformanceMode = performanceMode, EnableOrderFlowLayer = enableOrderFlowLayer, OrderFlowBlend = orderFlowBlend, EnableHistoricalSnapshotExport = enableHistoricalSnapshotExport, HistoricalExportDirectory = historicalExportDirectory }, input, ref cacheGlitchAnalyticsBridge);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GlitchAiMarketIngest GlitchAiMarketIngest(bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			return indicator.GlitchAiMarketIngest(Input, addPrimaryTimeframes, additionalInstrumentRoots);
		}

		public Indicators.GlitchAnalyticsBridge GlitchAnalyticsBridge(double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			return indicator.GlitchAnalyticsBridge(Input, neutralBand, enableBarColoring, publishToGlitchUi, publishIntervalMs, intraBarColoring, predictiveBoost, flipHysteresis, performanceMode, enableOrderFlowLayer, orderFlowBlend, enableHistoricalSnapshotExport, historicalExportDirectory);
		}


		
		public Indicators.GlitchAiMarketIngest GlitchAiMarketIngest(ISeries<double> input , bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			return indicator.GlitchAiMarketIngest(input, addPrimaryTimeframes, additionalInstrumentRoots);
		}

		public Indicators.GlitchAnalyticsBridge GlitchAnalyticsBridge(ISeries<double> input , double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			return indicator.GlitchAnalyticsBridge(input, neutralBand, enableBarColoring, publishToGlitchUi, publishIntervalMs, intraBarColoring, predictiveBoost, flipHysteresis, performanceMode, enableOrderFlowLayer, orderFlowBlend, enableHistoricalSnapshotExport, historicalExportDirectory);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GlitchAiMarketIngest GlitchAiMarketIngest(bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			return indicator.GlitchAiMarketIngest(Input, addPrimaryTimeframes, additionalInstrumentRoots);
		}

		public Indicators.GlitchAnalyticsBridge GlitchAnalyticsBridge(double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			return indicator.GlitchAnalyticsBridge(Input, neutralBand, enableBarColoring, publishToGlitchUi, publishIntervalMs, intraBarColoring, predictiveBoost, flipHysteresis, performanceMode, enableOrderFlowLayer, orderFlowBlend, enableHistoricalSnapshotExport, historicalExportDirectory);
		}


		
		public Indicators.GlitchAiMarketIngest GlitchAiMarketIngest(ISeries<double> input , bool addPrimaryTimeframes, string additionalInstrumentRoots)
		{
			return indicator.GlitchAiMarketIngest(input, addPrimaryTimeframes, additionalInstrumentRoots);
		}

		public Indicators.GlitchAnalyticsBridge GlitchAnalyticsBridge(ISeries<double> input , double neutralBand, bool enableBarColoring, bool publishToGlitchUi, int publishIntervalMs, bool intraBarColoring, double predictiveBoost, double flipHysteresis, bool performanceMode, bool enableOrderFlowLayer, double orderFlowBlend, bool enableHistoricalSnapshotExport, string historicalExportDirectory)
		{
			return indicator.GlitchAnalyticsBridge(input, neutralBand, enableBarColoring, publishToGlitchUi, publishIntervalMs, intraBarColoring, predictiveBoost, flipHysteresis, performanceMode, enableOrderFlowLayer, orderFlowBlend, enableHistoricalSnapshotExport, historicalExportDirectory);
		}

	}
}

#endregion
